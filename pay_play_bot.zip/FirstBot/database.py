import sqlite3


# Функция для получения соединения с базой данных
def get_db_connection():
    conn = sqlite3.connect('bot_database.db')
    conn.row_factory = sqlite3.Row  # Позволяет получать строки как словари
    return conn


# Создание таблицы для пользователей (если еще не создана)
def create_users_table():
    conn = get_db_connection()
    conn.execute('''CREATE TABLE IF NOT EXISTS users (
        user_id INTEGER PRIMARY KEY,
        username TEXT,
        balance INTEGER DEFAULT 0
    )''')
    conn.commit()
    conn.close()


# Создание таблицы для уведомлений
def create_notifications_table():
    conn = get_db_connection()
    conn.execute('''CREATE TABLE IF NOT EXISTS notifications (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER,
        username TEXT,
        product_name TEXT,
        first_name TEXT,
        game_category TEXT,
        timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY(user_id) REFERENCES users(user_id)
    )''')
    conn.commit()
    conn.close()


# Функция для добавления пользователя
def add_user(user_id, username):
    conn = get_db_connection()
    conn.execute('''INSERT OR IGNORE INTO users (user_id, username) VALUES (?, ?)''',
                 (user_id, username))
    conn.commit()
    conn.close()


# Функция для получения баланса пользователя
def get_user_balance(user_id):
    conn = get_db_connection()
    cursor = conn.execute('SELECT balance FROM users WHERE user_id = ?', (user_id,))
    result = cursor.fetchone()
    conn.close()

    if result:
        return result[0]  # Вернуть баланс
    return 0  # Если пользователь не найден, возвращаем 0


# Функция для обновления баланса пользователя
def update_user_balance(user_id, new_balance):
    conn = get_db_connection()
    conn.execute('UPDATE users SET balance = ? WHERE user_id = ?', (new_balance, user_id))
    conn.commit()
    conn.close()


# Функция для добавления уведомления
def add_notification(user_id, username, product_name, first_name, game_category):
    conn = get_db_connection()
    conn.execute('''INSERT INTO notifications (user_id, username, product_name, first_name, game_category)
                    VALUES (?, ?, ?, ?, ?)''',
                 (user_id, username, product_name, first_name, game_category))
    conn.commit()
    conn.close()


# Функция для получения всех уведомлений
def get_all_notifications():
    conn = get_db_connection()
    notifications = conn.execute('SELECT * FROM notifications ORDER BY timestamp DESC').fetchall()
    conn.close()
    return notifications


# Создание таблиц при запуске скрипта
create_users_table()
create_notifications_table()
