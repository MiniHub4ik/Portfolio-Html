import telebot
from telebot import types

from bot_instance import bot
from game_categories.clash_of_clans import handle_clash_of_clans
from game_categories.pubg_mobile import handle_pubg_mobile
from game_categories.brawl_stars import handle_brawl_stars
from game_categories.stumble_guys import handle_stumble_guys
from game_categories.efootball_pes import handle_efootball_pes
from info import handle_info, handle_guarantees, handle_bot_info
from registered_users import add_user
# from topup import handle_topup
from game_categories.free_fire import handle_free_fire, handle_free_fire_almazi, handle_free_fire_aksii
from admin_panel import add_notification
from admin_panel import admin_panel
from bot_instance import bot
from topup import handle_premium_subscription
from user_cabinet import show_user_cabinet

ADMIN_ID = 1686153131  # Замените на ваш реальный ID

# URL для изображений категорий
CATEGORY_IMAGES = {
    'games': 'https://ibb.co/tbPzmMb',
    'clash_of_clans': 'https://ibb.co/0jq0s7n',
    'pubg_mobile': 'https://ibb.co/KFhF9kw',
    'brawlstars': 'https://ibb.co/nRVLrmx',
    'stumble_guys': 'https://ibb.co/hFN1v1n',
    'free_fire': 'https://ibb.co/4ppmm6C',
    'efootball_pes': 'https://ibb.co/cvWwq11'
}



# Словарь для хранения ID сообщений
last_messages = {}
def handle_purchase(call, product_name, game_category):
    user_id = call.from_user.id
    username = call.from_user.username
    first_name = call.from_user.first_name

    add_notification(user_id, username, product_name, first_name, game_category)  # Добавляем уведомление
    bot.send_message(call.message.chat.id, f"Вы успешно купили {product_name}!")


@bot.message_handler(commands=['admin'])
def admin_command(message):
    if message.chat.id == ADMIN_ID:  # Убедитесь, что админ только имеет доступ
        admin_panel(message)
    else:
        bot.send_message(message.chat.id, "У вас нет доступа к админ-панели.")




@bot.message_handler(commands=['start'])
def start(message):
    user_id = message.from_user.id
    username = message.from_user.username
    first_name = message.from_user.first_name

    add_user(user_id, username, first_name)  # Добавляем пользователя в список зарегистрированных

    markup = types.InlineKeyboardMarkup(row_width=2)
    item1 = types.InlineKeyboardButton("Каталог Игр 🎮", callback_data='games')
    item2 = types.InlineKeyboardButton("Телеграм Премиум ⭐", callback_data='topup')
    item3 = types.InlineKeyboardButton("Поддержка 💻", callback_data='support')
    item4 = types.InlineKeyboardButton("Информация о боте ℹ️", callback_data='info')
    item5 = types.InlineKeyboardButton("Кабинет 👤", callback_data='cabinet')
    item6 = types.InlineKeyboardButton("Курс/Продать TonCoin 🪙", callback_data='toncoin')

    # Для админа добавим кнопку для назначения поддержки


    markup.add(item1, item2, item3, item4, item5, item6)

    sent_photo = bot.send_photo(message.chat.id, CATEGORY_IMAGES['games'])
    last_messages[message.chat.id] = {'photo_id': sent_photo.message_id}

    sent_message = bot.send_message(message.chat.id,
                                    'Здравствуйте, {0.first_name}! Пожалуйста, выберите раздел'.format(
                                        message.from_user),
                                    reply_markup=markup)
    last_messages[message.chat.id]['text_id'] = sent_message.message_id

@bot.callback_query_handler(func=lambda call: call.data == 'toncoin')
def ton_coin(call):
    markup = types.InlineKeyboardMarkup(row_width=1)
    item1 = types.InlineKeyboardButton("Курс TonCoin 🪙", callback_data='kurs_toncoin')
    item2 = types.InlineKeyboardButton("Продать TonCoin 🧾", callback_data='sell_toncoin')  # Изменено callback_data
    back = types.InlineKeyboardButton("Назад 🔙", callback_data='main_menu')
    markup.add(item1, item2, back)

    # Отправляем сообщение с разметкой пользователю
    bot.send_message(call.message.chat.id, "Выберите опцию для TonCoin:", reply_markup=markup)


@bot.callback_query_handler(func=lambda call: call.data == 'sell_toncoin')
def sell_toncoin(call):
    (bot.send_message(call.message.chat.id, "Информация о продаже TonCoin.")

@bot.callback_query_handler(func=lambda call: call.data == 'kurs_toncoin'))
def kurs_toncoin(call):
    bot.send_message(call.message.chat.id, "Информация о курсе TonCoin.")




# Обработка нажатия на кнопку "Поддержка"
@bot.callback_query_handler(func=lambda call: call.data == 'support')
def support_menu(call):
    markup = types.InlineKeyboardMarkup(row_width=1)
    item1 = types.InlineKeyboardButton("По вопросам и по предложениям 🙋‍♂️", url='https://t.me/nematilla')
    item2 = types.InlineKeyboardButton("Назад 🔙", callback_data='main_menu')
    markup.add(item1, item2)

    # Удаление текущего сообщения
    bot.delete_message(call.message.chat.id, call.message.message_id)

    # Отправка сообщения с клавиатурой
    bot.send_message(call.message.chat.id, "Выберите действие:", reply_markup=markup)


# Обработчик нажатия кнопки "Кабинет"
@bot.callback_query_handler(func=lambda call: call.data == 'cabinet')
def handle_cabinet(call):
    show_user_cabinet(call.message)


@bot.callback_query_handler(func=lambda call: True)
def callback_handler(call):
    # Удаляем предыдущее сообщение, если оно существует
    if call.message.chat.id in last_messages:
        if 'text_id' in last_messages[call.message.chat.id]:
            try:
                bot.delete_message(call.message.chat.id, last_messages[call.message.chat.id]['text_id'])
            except telebot.apihelper.ApiException:
                pass

        if 'photo_id' in last_messages[call.message.chat.id]:
            try:
                bot.delete_message(call.message.chat.id, last_messages[call.message.chat.id]['photo_id'])
            except telebot.apihelper.ApiException:
                pass

    if call.data == 'games':
        games_markup = types.InlineKeyboardMarkup(row_width=2)
        item1 = types.InlineKeyboardButton("Clash Of Clans 🛡️", callback_data='clash_of_clans')
        item2 = types.InlineKeyboardButton("Pubg Mobile 🍳", callback_data='pubg_mobile')
        item3 = types.InlineKeyboardButton("Brawl Stars 🌵", callback_data='brawlstars')
        item4 = types.InlineKeyboardButton("Stumble Guys 👑", callback_data='stumble_guys')
        item5 = types.InlineKeyboardButton("Free Fire 🔥", callback_data='free_fire')
        item6 = types.InlineKeyboardButton("eFootball(PES) ⚽", callback_data='efootball_pes')
        back = types.InlineKeyboardButton("Назад ↩️", callback_data='main_menu')

        games_markup.add(item1, item2, item3, item4, item5, item6, back)

        sent_photo = bot.send_photo(call.message.chat.id, CATEGORY_IMAGES['games'])
        last_messages[call.message.chat.id] = {'photo_id': sent_photo.message_id}

        sent_message = bot.send_message(call.message.chat.id, "Выберите игру:", reply_markup=games_markup)
        last_messages[call.message.chat.id]['text_id'] = sent_message.message_id


    elif call.data == 'brawlstars':
        sent_photo = bot.send_photo(call.message.chat.id, CATEGORY_IMAGES['brawlstars'])
        last_messages[call.message.chat.id] = {'photo_id': sent_photo.message_id}
        markup = handle_brawl_stars(call)  # Здесь должен быть возврат разметки
        sent_message = bot.send_message(call.message.chat.id, "Brawl Stars 🌵", reply_markup=markup)
        last_messages[call.message.chat.id]['text_id'] = sent_message.message_id


    elif call.data == 'free_fire':
        sent_photo = bot.send_photo(call.message.chat.id, CATEGORY_IMAGES['free_fire'])
        markup = handle_free_fire(call)  # Здесь должен быть возврат разметки
        sent_message = bot.send_message(call.message.chat.id, "Free Fire 🔥", reply_markup=markup)
        last_messages[call.message.chat.id] = {'photo_id': sent_photo.message_id}  # Сохраняем ID отправленного изображения

        last_messages[call.message.chat.id]['text_id'] = sent_message.message_id  # Сохраняем ID отправленного текстового сообщения

    elif call.data == 'free_fire_almazi':
        sent_photo = bot.send_photo(call.message.chat.id, CATEGORY_IMAGES['free_fire'])
        last_messages[call.message.chat.id] = {'photo_id': sent_photo.message_id}  # Сохраняем ID отправленного изображения

        sent_message = bot.send_message(call.message.chat.id, "Выберите количество Алмазов:", reply_markup=handle_free_fire_almazi(call))
        last_messages[call.message.chat.id]['text_id'] = sent_message.message_id  # Сохраняем ID отправленного текстового сообщения

    elif call.data == 'free_fire_aksii':
        sent_photo = bot.send_photo(call.message.chat.id, CATEGORY_IMAGES['free_fire'])
        last_messages[call.message.chat.id] = {'photo_id': sent_photo.message_id}  # Сохраняем ID отправленного изображения

        sent_message = bot.send_message(call.message.chat.id, "Выберите Акции:", reply_markup=handle_free_fire_aksii(call))
        last_messages[call.message.chat.id]['text_id'] = sent_message.message_id  # Сохраняем ID отправленного текстового сообщения

    elif call.data == 'topup':
        # Логика для тг премиум
        markup = handle_premium_subscription(call)  # Вызов функции для обработки пополнения
        sent_message = bot.send_message(call.message.chat.id, "Телеграм Премиум ⭐", reply_markup=markup)
        last_messages[call.message.chat.id][
            'text_id'] = sent_message.message_id  # Сохраняем ID отправленного текстового сообщения

    elif call.data == 'info':
        info_text, markup = handle_bot_info(call)  # Получаем текст и разметку
        sent_message = bot.send_message(call.message.chat.id, info_text, reply_markup=markup,
                                        parse_mode='HTML')  # Используем HTML для форматирования
        last_messages[call.message.chat.id][
            'text_id'] = sent_message.message_id  # Сохраняем ID отправленного текстового сообщения

    # elif call.data == 'support':
    #     # Обработчик для раздела поддержки
    #     support_markup = types.InlineKeyboardMarkup(row_width=1)
    #     item1 = types.InlineKeyboardButton("По вопросам и по предложениям 🙋‍♂️", url='https://t.me/nematilla')
    #     back = types.InlineKeyboardButton("Назад ↩️", callback_data='main_menu')
    #     support_markup.add(item1, back)
    #
    #     sent_message = bot.send_message(call.message.chat.id, "Поддержка 💻", reply_markup=support_markup)
    #     last_messages[call.message.chat.id][
    #         'text_id'] = sent_message.message_id  # Сохраняем ID отправленного текстового сообщения

    # Остальные обработчики для игр
    elif call.data == 'clash_of_clans':
        sent_photo = bot.send_photo(call.message.chat.id, CATEGORY_IMAGES['clash_of_clans'])
        last_messages[call.message.chat.id] = {'photo_id': sent_photo.message_id}
        markup = handle_clash_of_clans(call)
        sent_message = bot.send_message(call.message.chat.id, "Clash Of Clans 🛡️", reply_markup=markup)
        last_messages[call.message.chat.id]['text_id'] = sent_message.message_id

    elif call.data == 'pubg_mobile':
        sent_photo = bot.send_photo(call.message.chat.id, CATEGORY_IMAGES['pubg_mobile'])
        last_messages[call.message.chat.id] = {'photo_id': sent_photo.message_id}
        markup = handle_pubg_mobile(call)
        sent_message = bot.send_message(call.message.chat.id, "Pubg Mobile 🍳", reply_markup=markup)
        last_messages[call.message.chat.id]['text_id'] = sent_message.message_id



    elif call.data == 'stumble_guys':
        sent_photo = bot.send_photo(call.message.chat.id, CATEGORY_IMAGES['stumble_guys'])
        last_messages[call.message.chat.id] = {'photo_id': sent_photo.message_id}
        markup = handle_stumble_guys(call)
        sent_message = bot.send_message(call.message.chat.id, "Stumble Guys 👑", reply_markup=markup)
        last_messages[call.message.chat.id]['text_id'] = sent_message.message_id

    elif call.data == 'efootball_pes':
        sent_photo = bot.send_photo(call.message.chat.id, CATEGORY_IMAGES['efootball_pes'])
        last_messages[call.message.chat.id] = {'photo_id': sent_photo.message_id}
        markup = handle_efootball_pes(call)
        sent_message = bot.send_message(call.message.chat.id, "eFootball(PES) ⚽", reply_markup=markup)
        last_messages[call.message.chat.id]['text_id'] = sent_message.message_id

    elif call.data == 'main_menu':
        start(call.message)  # Возвращаемся к главному меню

    elif call.data == 'guarantees':
        guarantees_text, guarantees_markup = handle_guarantees(call)  # Получаем текст и разметку для гарантий
        sent_message = bot.send_message(call.message.chat.id, guarantees_text, reply_markup=guarantees_markup, parse_mode='HTML')  # Используем HTML для форматирования
        last_messages[call.message.chat.id]['text_id'] = sent_message.message_id  # Сохраняем ID отправленного текстового сообщения



    # Обработка покупки
    elif call.data.startswith('purchase_'):
        product_name = call.data.split('_')[1]  # Получаем название продукта из callback_data
        user_id = call.from_user.id
        username = call.from_user.username if call.from_user.username else call.from_user.first_name  # Используем имя, если юзер не указан
        game_category = 'Free Fire' if call.data.startswith(
            'purchase_') else 'Неизвестная категория'  # Устанавливаем категорию игры

        add_notification(user_id, username, product_name, call.from_user.first_name,
                         game_category)  # Передаем все необходимые параметры

        # Создаем клавиатуру для главного меню
        main_menu_keyboard = telebot.types.InlineKeyboardMarkup()
        main_menu_button = telebot.types.InlineKeyboardButton("Главное меню", callback_data="main_menu")
        main_menu_keyboard.add(main_menu_button)

        # Отправляем сообщение о подтверждении покупки
        bot.send_message(call.message.chat.id, f"Вы успешно купили {product_name}!", reply_markup=main_menu_keyboard)

    @bot.callback_query_handler(func=lambda call: call.data == "main_menu")
    def handle_main_menu(call):
        # Здесь вы можете показать главное меню пользователю
        bot.send_message(call.message.chat.id, "Вы в главном меню!")


bot.polling(none_stop=True)
