from telebot import types
from admin_panel import add_notification

def handle_free_fire(call):
    markup = types.InlineKeyboardMarkup(row_width=2)
    item1 = types.InlineKeyboardButton("Купить Алмазы 💎", callback_data='free_fire_almazi')
    item2 = types.InlineKeyboardButton("Купить Акции 🎁", callback_data='free_fire_aksii')
    back = types.InlineKeyboardButton("Назад ↩️", callback_data='games')

    markup.add(item1, item2, back)
    return markup

def handle_free_fire_almazi(call):
    markup = types.InlineKeyboardMarkup(row_width=2)
    item1 = types.InlineKeyboardButton("100 Алмазов 💎", callback_data='purchase_100_diamonds')
    item2 = types.InlineKeyboardButton("200 Алмазов 💎", callback_data='purchase_200_diamonds')
    item3 = types.InlineKeyboardButton("500 Алмазов 💎", callback_data='purchase_500_diamonds')
    item4 = types.InlineKeyboardButton("1000 Алмазов 💎", callback_data='purchase_1000_diamonds')  # Renamed to item4
    back = types.InlineKeyboardButton("Назад ↩️", callback_data='free_fire')

    markup.add(item1, item2, item3, item4, back)
    return markup


def handle_free_fire_aksii(call):
    markup = types.InlineKeyboardMarkup(row_width=2)
    item1 = types.InlineKeyboardButton("Месячный ваучер 🎁", callback_data='purchase_Месячный Ваучер_voucher')
    item2 = types.InlineKeyboardButton("Недельный ваучер 🎁", callback_data='purchase_Недельный Ваучер_voucher')
    item3 = types.InlineKeyboardButton("Другая акция 🎁", callback_data='purchase_Другую Акцию')
    back = types.InlineKeyboardButton("Назад ↩️", callback_data='free_fire')

    markup.add(item1, item2, item3, back)
    return markup

def handle_purchase_callback(call):
    product = call.data.split('_')[1]  # Извлекаем продукт из данных
    user_id = call.from_user.id
    username = call.from_user.username
    first_name = call.from_user.first_name  # Get first name
    game_category = 'Free Fire'  # Define the game category
    add_notification(user_id, username, product, first_name, game_category)  # Add first name and game category
    response_text = f"Вы успешно приобрели {product}!"
    return response_text

