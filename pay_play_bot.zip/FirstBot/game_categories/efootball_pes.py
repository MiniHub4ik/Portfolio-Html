from telebot import types

from admin_panel import add_notification
from bot_instance import bot


def handle_efootball_pes(call):
    markup = types.InlineKeyboardMarkup(row_width=2)
    item1 = types.InlineKeyboardButton("500 Гемов", callback_data='efootball_pes_500')
    item2 = types.InlineKeyboardButton("1500 Гемов", callback_data='efootball_pes_1500')
    item3 = types.InlineKeyboardButton("2500 Гемов", callback_data='efootball_pes_2500')
    item4 = types.InlineKeyboardButton("5000 Гемов", callback_data='efootball_pes_5000')
    back = types.InlineKeyboardButton("Назад ↩️", callback_data='games')
    markup.add(item1, item2, item3, item4, back)
    return markup

def handle_purchase_efootball_pes(call, amount):
    user_id = call.from_user.id
    username = call.from_user.username
    first_name = call.from_user.first_name
    product_name = f"{amount} Гемов в eFootball PES"

    add_notification(user_id, username, product_name, first_name, 'eFootball PES')

    bot.send_message(call.message.chat.id, f"Вы успешно купили {product_name}!")
