from telebot import types

from admin_panel import add_notification
from bot_instance import bot


def handle_pubg_mobile(call):
    markup = types.InlineKeyboardMarkup(row_width=2)
    item1 = types.InlineKeyboardButton("500 Гемов", callback_data='pubg_mobile_500')
    item2 = types.InlineKeyboardButton("1500 Гемов", callback_data='pubg_mobile_1500')
    item3 = types.InlineKeyboardButton("2500 Гемов", callback_data='pubg_mobile_2500')
    item4 = types.InlineKeyboardButton("5000 Гемов", callback_data='pubg_mobile_5000')
    back = types.InlineKeyboardButton("Назад ↩️", callback_data='games')
    markup.add(item1, item2, item3, item4, back)
    return markup

def handle_purchase_pubg_mobile(call, amount):
    user_id = call.from_user.id
    username = call.from_user.username
    first_name = call.from_user.first_name
    product_name = f"{amount} Гемов в PUBG Mobile"

    add_notification(user_id, username, product_name, first_name, 'PUBG Mobile')

    bot.send_message(call.message.chat.id, f"Вы успешно купили {product_name}!")
