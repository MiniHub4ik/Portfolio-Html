from telebot import types
from bot_instance import bot
from admin_panel import add_notification, ADMIN_ID


def handle_clash_of_clans(call):
    markup = types.InlineKeyboardMarkup(row_width=2)
    item1 = types.InlineKeyboardButton("500 Гемов", callback_data='clash_of_clans_500')
    item2 = types.InlineKeyboardButton("1500 Гемов", callback_data='clash_of_clans_1500')
    item3 = types.InlineKeyboardButton("2500 Гемов", callback_data='clash_of_clans_2500')
    item4 = types.InlineKeyboardButton("5000 Гемов", callback_data='clash_of_clans_5000')
    back = types.InlineKeyboardButton("Назад ↩️", callback_data='games')
    markup.add(item1, item2, item3, item4, back)
    return markup






def handle_purchase_clash_of_clans(call, amount):
    user_id = call.from_user.id
    username = call.from_user.username
    first_name = call.from_user.first_name
    product_name = f"{amount} Гемов в Clash of Clans"

    # Получаем цену товара и баланс пользователя
    item_price = get_item_price(amount)
    current_balance = get_user_balance(user_id)

    # Проверяем, достаточно ли у пользователя баланса для покупки
    if current_balance >= item_price:
        # Обновляем баланс пользователя
        new_balance = current_balance - item_price
        update_user_balance(user_id, new_balance)

        # Добавление уведомления для админа
        add_notification(user_id, username, product_name, first_name, 'Clash of Clans')

        # Отправка сообщения пользователю
        bot.send_message(call.message.chat.id, f"Вы успешно купили {product_name}!")
    else:
        bot.send_message(call.message.chat.id, "❌ У вас недостаточно средств для покупки.")


