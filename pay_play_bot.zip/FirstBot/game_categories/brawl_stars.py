from telebot import types
from bot_instance import bot
from admin_panel import add_notification

def handle_brawl_stars(call):
    markup = types.InlineKeyboardMarkup(row_width=2)
    item1 = types.InlineKeyboardButton("30 Гемов", callback_data='brawl_stars_30')
    item2 = types.InlineKeyboardButton("90 Гемов", callback_data='brawl_stars_90')
    item3 = types.InlineKeyboardButton("170 Гемов", callback_data='brawl_stars_170')
    item4 = types.InlineKeyboardButton("320 Гемов", callback_data='brawl_stars_320')
    item5 = types.InlineKeyboardButton("980 Гемов", callback_data='brawl_stars_980')
    item6 = types.InlineKeyboardButton("2000 Гемов", callback_data='brawl_stars_2000')
    back = types.InlineKeyboardButton("Назад ↩️", callback_data='games')
    markup.add(item1, item2, item3, item4, item5, item6, back)

    # Отправляем сообщение с кнопками
    return markup  # Return the markup instead of sending the message directly


@bot.callback_query_handler(func=lambda call: call.data.startswith('brawl_stars_'))
def callback_brawl_stars(call):
    amount_map = {
        'brawl_stars_30': 30,
        'brawl_stars_90': 90,
        'brawl_stars_170': 170,
        'brawl_stars_320': 320,
        'brawl_stars_980': 980,
        'brawl_stars_2000': 2000,
    }

    amount = amount_map.get(call.data)
    if amount:
        handle_purchase_brawl_stars(call, amount)


def handle_purchase_brawl_stars(call, amount):
    user_id = call.from_user.id
    username = call.from_user.username if call.from_user.username else "неизвестный"
    first_name = call.from_user.first_name
    product_name = f"{amount} Гемов в Brawl Stars"

    # Уведомление админам
    add_notification(user_id, username, product_name, first_name, 'Brawl Stars')

    # Сообщение пользователю
    bot.send_message(call.message.chat.id, f"Вы успешно купили {product_name}!")

    # Уведомляем Telegram, чтобы убрать кнопку, которая вызвала коллбэк
    bot.answer_callback_query(call.id)
