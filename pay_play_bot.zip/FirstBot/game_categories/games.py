
from telebot import types


def handle_games(call):
    # Создание клавиатуры с играми
    games_markup = types.InlineKeyboardMarkup(row_width=2)
    item1 = types.InlineKeyboardButton("Clash Of Clans 🛡️", callback_data='clash_of_clans')
    item2 = types.InlineKeyboardButton("Pubg Mobile 🍳", callback_data='pubg_mobile')
    item3 = types.InlineKeyboardButton("Brawl Stars 🌵", callback_data='brawlstars')
    item4 = types.InlineKeyboardButton("Stumble Guys 👑", callback_data='stumble_guys')
    item5 = types.InlineKeyboardButton("Free Fire 🔥", callback_data='free_fire')
    item6 = types.InlineKeyboardButton("eFootball(PES) ⚽", callback_data='efootball_pes')
    back = types.InlineKeyboardButton("Назад ↩️", callback_data='back')

    games_markup.add(item1, item2, item3, item4, item5, item6, back)

    # Отправка сообщения с клавиатурой
    return games_markup
