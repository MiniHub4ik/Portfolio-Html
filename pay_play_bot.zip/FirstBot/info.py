from telebot import types

def handle_info(call):
    markup = types.InlineKeyboardMarkup(row_width=1)
    item1 = types.InlineKeyboardButton("Гарантии 💼", callback_data='guarantees')
    item2 = types.InlineKeyboardButton("Информация о боте ℹ️", callback_data='bot_info')
    back = types.InlineKeyboardButton("Назад ↩️", callback_data='main_menu')
    markup.add(item1, item2, back)

    return markup

def handle_guarantees(call):
    markup = types.InlineKeyboardMarkup(row_width=1)
    back = types.InlineKeyboardButton("Назад ↩️", callback_data='info')
    markup.add(back)

    # Текст о гарантиях
    guarantees_text = """
💼 <b>Наши Гарантии</b> 💼

✔️ Гарантия на все покупки в течение 7 дней
✔️ Безопасные и проверенные методы оплаты
✔️ Полная поддержка на всех этапах покупки
✔️ Возврат средств в случае непредвиденных проблем
    """

    return guarantees_text, markup

def handle_bot_info(call):
    info_text = (
        "ℹ️ <b>Информация о боте</b> ℹ️\n\n"
        "Этот бот был создан для помощи пользователям в покупке виртуальных товаров и услуг. "
        "Мы предлагаем широкий выбор игр и пополнение различных сервисов, а также предоставляем гарантии и поддержку.\n\n"
        "Разработчик: @nematilla"
    )
    markup = types.InlineKeyboardMarkup()
    guarantees_button = types.InlineKeyboardButton("Гарантии 📜", callback_data='guarantees')
    back_button = types.InlineKeyboardButton("Назад ↩️", callback_data='main_menu')
    markup.add(guarantees_button, back_button)

    return info_text, markup

