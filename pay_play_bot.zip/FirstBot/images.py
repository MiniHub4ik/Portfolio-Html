# # images.py
# def get_image_for_category(category):
#     images = {
#         'games': 'images/games.jpg',
#         'clash_of_clans': 'images/clash_of_clans.jpg',
#         'free_fire': 'images/free_fire.jpg',
#         'pubg_mobile': 'images/pubg_mobile.jpg',
#         'brawl_stars': 'images/brawl_stars.jpg',
#         'stumble_guys': 'images/stumble_guys.jpg',
#         'efootball_pes': 'images/efootball_pes.jpg',
#     }
#
#     # Возвращаем путь к изображению в зависимости от категории
#     return images.get(category, 'images/default.jpg')
