from telebot import types
from admin_panel import add_notification
from bot_instance import bot
from registered_users import get_user_balance
from database import get_user_balance, update_user_balance, add_notification

def handle_premium_subscription(call):
    markup = types.InlineKeyboardMarkup(row_width=2)
    item1 = types.InlineKeyboardButton("1 месяц 🗓️ 500", callback_data='premium_1_month')
    item2 = types.InlineKeyboardButton("3 месяца 🗓️ 1300", callback_data='premium_3_months')
    item3 = types.InlineKeyboardButton("6 месяцев 🗓️ 2400", callback_data='premium_6_months')
    item4 = types.InlineKeyboardButton("12 месяцев 🗓️ 4200", callback_data='premium_12_months')
    back = types.InlineKeyboardButton("Назад ↩️", callback_data='main_menu')

    markup.add(item1, item2, item3, item4, back)
    bot.send_message(call.message.chat.id, "Выберите срок подписки на Telegram Premium:", reply_markup=markup)




def handle_purchase_premium(call, duration):
    user_id = call.from_user.id
    username = call.from_user.username
    first_name = call.from_user.first_name

    prices = {
        'premium_1_month': 500,
        'premium_3_months': 1300,
        'premium_6_months': 2400,
        'premium_12_months': 4200
    }

    amount = prices.get(call.data, 0)
    product_name = f"Подписка на Telegram Premium на {duration}"

    # Проверка баланса пользователя
    user_balance = get_user_balance(user_id)  # Получаем баланс из базы данных
    if user_balance < amount:
        bot.send_message(call.message.chat.id, "У вас недостаточно средств для покупки этой подписки. Пожалуйста, пополните свой счет.")
        return

    # Обновление баланса пользователя
    new_balance = user_balance - amount
    update_user_balance(user_id, new_balance)

    # Добавление уведомления о покупке
    add_notification(user_id, username, product_name, first_name, 'Premium Subscription')
    bot.send_message(call.message.chat.id, f"Вы успешно приобрели {product_name} за {amount} Рублей!")



# Обработка нажатий на кнопки подписки
@bot.callback_query_handler(func=lambda call: call.data.startswith('premium_'))
def process_premium_subscription(call):
    durations = {
        'premium_1_month': '1 месяц',
        'premium_3_months': '3 месяца',
        'premium_6_months': '6 месяцев',
        'premium_12_months': '12 месяцев'
    }

    duration = durations.get(call.data)
    if duration:
        handle_purchase_premium(call, duration)


# Команда для начала покупки подписки
@bot.callback_query_handler(func=lambda call: call.data == 'buy_premium')
def initiate_premium_purchase(call):
    handle_premium_subscription(call)
