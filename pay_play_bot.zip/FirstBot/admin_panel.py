import telebot
from telebot import types
from datetime import datetime
from bot_instance import bot
from registered_users import add_user, get_all_users, top_up_balance

ADMIN_ID = 1686153131  # Ваш Telegram ID
notifications = []  # Хранилище уведомлений
user_page = {}  # Отслеживание текущей страницы для каждого администратора


# Создаем админ-панель
def create_admin_panel_keyboard():
    markup = types.InlineKeyboardMarkup(row_width=1)
    view_notifications_btn = types.InlineKeyboardButton("📝 Посмотреть уведомления", callback_data='view_notifications')
    send_message_btn = types.InlineKeyboardButton("✉️ Отправить сообщение всем пользователям",
                                                  callback_data='send_message')
    view_users_btn = types.InlineKeyboardButton("👥 Показать всех зарегистрированных пользователей",
                                                callback_data='view_users')
    top_up_balance_btn = types.InlineKeyboardButton("💰 Пополнить баланс", callback_data='top_up_balance')

    markup.add(view_notifications_btn, send_message_btn, view_users_btn, top_up_balance_btn)
    return markup


# Команда для входа в админ-панель
@bot.message_handler(commands=['admin'])
def admin_panel(message):
    if message.from_user.id == ADMIN_ID:
        markup = create_admin_panel_keyboard()
        bot.send_message(message.chat.id, "Добро пожаловать в админ-панель! Выберите действие:", reply_markup=markup)
    else:
        bot.send_message(message.chat.id, "❌ У вас нет доступа к админ-панели.")


# Показ всех зарегистрированных пользователей с пагинацией
@bot.callback_query_handler(func=lambda call: call.data == 'view_users')
def view_registered_users(call):
    user_page[call.from_user.id] = 0  # Устанавливаем начальную страницу на 0
    show_users_page(call.message, user_page[call.from_user.id])


def show_users_page(message, page):
    users = get_all_users()
    total_pages = (len(users) - 1) // 5 + 1  # Расчет количества страниц
    start_index = page * 5
    end_index = start_index + 5
    users_on_page = users[start_index:end_index]

    if users_on_page:
        user_list = "\n".join(
            [f"{start_index + index + 1}. <a href='tg://user?id={user['id']}'>{user['first_name']}</a>" for index, user
             in enumerate(users_on_page)]
        )
        bot.send_message(
            message.chat.id,
            f"👥 Зарегистрированные пользователи (Страница {page + 1} из {total_pages}):\n{user_list}",
            parse_mode='HTML'
        )

        # Создаем кнопки для навигации
        markup = types.InlineKeyboardMarkup()
        if page > 0:
            markup.add(types.InlineKeyboardButton("⬅️ Предыдущая страница", callback_data='prev_page'))
        if page < total_pages - 1:
            markup.add(types.InlineKeyboardButton("➡️ Следующая страница", callback_data='next_page'))
        markup.add(types.InlineKeyboardButton("🔙 Назад в админ-панель", callback_data='admin_panel'))

        bot.send_message(message.chat.id, "Выберите действие:", reply_markup=markup)
    else:
        bot.send_message(message.chat.id, "❌ Нет зарегистрированных пользователей.")


# Обработка кнопок "Следующая страница" и "Предыдущая страница"
@bot.callback_query_handler(func=lambda call: call.data in ['next_page', 'prev_page'])
def handle_pagination(call):
    current_page = user_page.get(call.from_user.id, 0)
    if call.data == 'next_page':
        user_page[call.from_user.id] = current_page + 1
    elif call.data == 'prev_page' and current_page > 0:
        user_page[call.from_user.id] = current_page - 1

    # Удаляем текущее сообщение и показываем обновленную страницу
    bot.delete_message(call.message.chat.id, call.message.message_id)
    show_users_page(call.message, user_page[call.from_user.id])

# Обработчик для просмотра уведомлений
@bot.callback_query_handler(func=lambda call: call.data == 'view_notifications')
def view_notifications(call):
    bot.delete_message(call.message.chat.id, call.message.message_id)
    if notifications:
        messages = [f"{index}. {text} в {date}" for index, (date, text) in enumerate(notifications, start=1)]
        bot.send_message(call.message.chat.id, "\n".join(messages), parse_mode='HTML')
    else:
        bot.send_message(call.message.chat.id, "❌ Нет новых уведомлений.")

    markup = create_admin_panel_keyboard()
    bot.send_message(call.message.chat.id, "Выберите действие:", reply_markup=markup)


# Отправка сообщения всем пользователям
@bot.callback_query_handler(func=lambda call: call.data == 'send_message')
def prompt_send_message(call):
    bot.delete_message(call.message.chat.id, call.message.message_id)
    msg = bot.send_message(call.message.chat.id, "📝 Введите текст сообщения (или отправьте изображение):")
    bot.register_next_step_handler(msg, send_message_to_users)


# Обработка отправки сообщения пользователям
def send_message_to_users(message):
    if message.content_type == 'text':
        text = message.text
    elif message.content_type == 'photo':
        photo = message.photo[-1]
        text = message.caption if message.caption else ""
    else:
        bot.send_message(message.chat.id, "❌ Неверный тип сообщения. Пожалуйста, отправьте текст или изображение.")
        return

    registered_users = get_all_users()
    for user in registered_users:
        user_id = user['id']
        try:
            if message.content_type == 'text':
                bot.send_message(user_id, text)
            elif message.content_type == 'photo':
                bot.send_photo(user_id, photo.file_id, caption=text)
        except Exception as e:
            print(f"❌ Не удалось отправить сообщение пользователю {user_id}: {e}")

    bot.send_message(message.chat.id, "✅ Сообщение отправлено всем зарегистрированным пользователям.")
    markup = create_admin_panel_keyboard()
    bot.send_message(message.chat.id, "Выберите действие:", reply_markup=markup)


# Показ всех зарегистрированных пользователей
@bot.callback_query_handler(func=lambda call: call.data == 'view_users')
def view_registered_users(call):
    bot.delete_message(call.message.chat.id, call.message.message_id)
    users = get_all_users()
    if users:
        user_list = "\n".join([f"User ID: {user['id']}, Имя: {user['first_name']}" for user in users])
        bot.send_message(call.message.chat.id, f"👥 Зарегистрированные пользователи:\n{user_list}")
    else:
        bot.send_message(call.message.chat.id, "❌ Нет зарегистрированных пользователей.")

    markup = create_admin_panel_keyboard()
    bot.send_message(call.message.chat.id, "Выберите действие:", reply_markup=markup)


# Добавление уведомлений
def add_notification(user_id, username, product_name, first_name, game_category):
    date = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    display_name = username if username else first_name
    notification = f"Пользователь <a href='tg://user?id={user_id}'>{display_name}</a> купил товар '{product_name}' в категории '{game_category}'"
    notifications.append((date, notification))
    bot.send_message(ADMIN_ID, f"📩 Новое уведомление: {notification} в {date}", parse_mode='HTML')


if __name__ == '__main__':
    bot.polling(none_stop=True)
