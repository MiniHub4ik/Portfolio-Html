# import telebot
# from telebot import types
# import json
# import os
# from admin_panel import get_admin_ids  # Импортируем функцию для получения ID администраторов
#
# # Создаем экземпляр бота
# bot = telebot.TeleBot('YOUR_BOT_TOKEN')  # Замените на ваш токен
#
# SUPPORT_TICKETS_FILE = 'support_tickets.json'
#
#
# # Загружаем тикеты из файла
# def load_support_tickets():
#     if os.path.exists(SUPPORT_TICKETS_FILE):
#         with open(SUPPORT_TICKETS_FILE, 'r') as file:
#             return json.load(file)
#     return []
#
#
# # Сохраняем тикеты в файл
# def save_support_tickets(tickets):
#     with open(SUPPORT_TICKETS_FILE, 'w') as file:
#         json.dump(tickets, file, indent=4)
#
#
# # Создаем новый тикет
# def create_ticket(user_id, title, description, attachment):
#     tickets = load_support_tickets()
#     ticket_id = len(tickets) + 1  # Простой инкремент для ID тикета
#     tickets.append({
#         'id': ticket_id,
#         'user_id': user_id,
#         'title': title,
#         'description': description,
#         'attachment': attachment,
#         'status': 'open'  # Статус тикета
#     })
#     save_support_tickets(tickets)
#
#
# # Кнопка «Назад»
# def back_button():
#     markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
#     markup.add(types.KeyboardButton("🔙 Назад"))
#     return markup
#
#
# # Команда для создания тикета
# @bot.message_handler(commands=['create_ticket'])
# def prompt_ticket_title(message):
#     msg = bot.send_message(message.chat.id, "Введите заголовок тикета (макс. 30 символов):", reply_markup=back_button())
#     bot.register_next_step_handler(msg, process_ticket_title)
#
#
# def process_ticket_title(message):
#     if message.text == "🔙 Назад":
#         bot.send_message(message.chat.id, "Вы вернулись назад.", reply_markup=types.ReplyKeyboardRemove())
#         return
#
#     title = message.text
#     if len(title) > 30:
#         bot.send_message(message.chat.id, "❌ Заголовок слишком длинный! Попробуйте еще раз.")
#         return prompt_ticket_title(message)
#
#     msg = bot.send_message(message.chat.id, "Опишите проблему (макс. 500 символов):", reply_markup=back_button())
#     bot.register_next_step_handler(msg, process_ticket_description, title)
#
#
# def process_ticket_description(message, title):
#     if message.text == "🔙 Назад":
#         bot.send_message(message.chat.id, "Вы вернулись назад.", reply_markup=types.ReplyKeyboardRemove())
#         return
#
#     description = message.text
#     if len(description) > 500:
#         bot.send_message(message.chat.id, "❌ Описание слишком длинное! Попробуйте еще раз.")
#         return prompt_ticket_description(message, title)
#
#     msg = bot.send_message(message.chat.id,
#                            "Вы можете прикрепить фото или видео. Отправьте их сейчас или напишите 'Пропустить' для продолжения.")
#     bot.register_next_step_handler(msg, process_ticket_attachment, title, description)
#
#
# def process_ticket_attachment(message, title, description):
#     if message.text == "🔙 Назад":
#         bot.send_message(message.chat.id, "Вы вернулись назад.", reply_markup=types.ReplyKeyboardRemove())
#         return
#
#     if message.content_type in ['photo', 'video']:
#         attachment = message.json  # Сохраните ссылку на вложение
#     else:
#         attachment = None  # Без вложения
#
#     create_ticket(message.from_user.id, title, description, attachment)
#     bot.send_message(message.chat.id, "✅ Тикет успешно создан!")
#
#
# # Команда для входа в поддержку
# @bot.message_handler(commands=['staff'])
# def staff_panel(message):
#     admins = get_admin_ids()  # Получаем список ID администраторов
#     if message.from_user.id in admins:
#         bot.send_message(message.chat.id, "Добро пожаловать в панель поддержки!", reply_markup=back_button())
#         # Здесь можно добавить код для отображения открытых тикетов
#     else:
#         bot.send_message(message.chat.id, "❌ У вас нет доступа к этой команде.")
#
#
# def create_ticket(user_id, title, description, media):
#     # Логика создания тикета
#     pass
#
# if __name__ == '__main__':
#     bot.polling(none_stop=True)
