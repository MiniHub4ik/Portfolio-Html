import json
import os

REGISTERED_USERS_FILE = 'registered_users.json'

# Загрузить всех зарегистрированных пользователей
def load_registered_users():
    if os.path.exists(REGISTERED_USERS_FILE):
        with open(REGISTERED_USERS_FILE, 'r') as file:
            return json.load(file)
    return []

# Сохранить список зарегистрированных пользователей
def save_registered_users(users):
    with open(REGISTERED_USERS_FILE, 'w') as file:
        json.dump(users, file, indent=4)

# Получить баланс пользователя по его ID
def get_user_balance(user_id):
    users = load_registered_users()
    for user in users:
        if user['id'] == user_id:
            return user.get('balance', 0)  # Вернуть баланс или 0, если его нет
    return None

# Получить последние покупки пользователя
def get_recent_purchases(user_id, num_purchases=5):
    users = load_registered_users()
    for user in users:
        if user['id'] == user_id:
            purchases = user.get('purchases', [])
            return purchases[-num_purchases:]  # Вернуть последние покупки
    return []

# Получить все покупки пользователя
def get_user_purchases(user_id):
    users = load_registered_users()
    for user in users:
        if user['id'] == user_id:
            return user.get('purchases', [])
    return []

# Добавить нового пользователя
def add_user(user_id, username, first_name):
    users = load_registered_users()
    if not any(user['id'] == user_id for user in users):  # Проверка на существование пользователя
        users.append({
            'id': user_id,
            'username': username,
            'first_name': first_name,
            'balance': 0,  # Инициализация баланса
            'purchases': []  # Инициализация покупок
        })
        save_registered_users(users)

# Пополнить баланс пользователя
def top_up_balance(user_id, amount):
    users = load_registered_users()
    for user in users:
        if user['id'] == user_id:
            user['balance'] = user.get('balance', 0) + amount
            save_registered_users(users)
            return user['balance']  # Вернуть обновленный баланс
    return None

# Обеспечить наличие поля баланса у всех пользователей
def ensure_balance_field():
    users = load_registered_users()
    for user in users:
        if 'balance' not in user:
            user['balance'] = 0
    save_registered_users(users)

# Получить всех зарегистрированных пользователей
def get_all_users():
    return load_registered_users()

if __name__ == '__main__':
    ensure_balance_field()
    add_user(123, 'testuser', 'Test')
    print(get_all_users())
    top_up_balance(123, 50)
    print(get_all_users())
