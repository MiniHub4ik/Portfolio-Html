import telebot
from telebot import types
from datetime import datetime

from admin_panel import ADMIN_ID
from registered_users import get_user_balance, get_recent_purchases
from bot_instance import bot

# Словарь для хранения состояния пользователей
user_states = {}




def create_user_cabinet_keyboard():
    markup = types.InlineKeyboardMarkup()
    balance_btn = types.InlineKeyboardButton("💰 Баланс", callback_data='check_balance')
    recent_purchases_btn = types.InlineKeyboardButton("🛍️ Недавние покупки", callback_data='recent_purchases')
    back_btn = types.InlineKeyboardButton("🔙 Назад", callback_data='back_to_main_menu')

    # Добавляем кнопки одну за другой, что размещает их вертикально
    markup.add(balance_btn)
    markup.add(recent_purchases_btn)
    markup.add(back_btn)

    return markup


def show_user_cabinet(message):
    markup = create_user_cabinet_keyboard()
    bot.send_message(message.chat.id, "Добро пожаловать в ваш кабинет! Выберите действие:", reply_markup=markup)


@bot.message_handler(commands=['cabinet'])
def user_cabinet(message):
    show_user_cabinet(message)


@bot.callback_query_handler(func=lambda call: call.data == 'check_balance')
def check_balance(call):
    user_id = call.from_user.id
    balance = get_user_balance(user_id)

    markup = types.InlineKeyboardMarkup()
    top_up_btn = types.InlineKeyboardButton("💳 Пополнить баланс", callback_data='add_funds')
    back_btn = types.InlineKeyboardButton("🔙 Назад", callback_data='back_to_user_cabinet')
    markup.add(top_up_btn, back_btn)

    balance_message = f"🌟 Ваш баланс: {balance} 💵"

    # Удаляем предыдущее сообщение перед отправкой нового
    bot.delete_message(call.message.chat.id, call.message.message_id)

    bot.send_message(call.message.chat.id, balance_message, reply_markup=markup)


@bot.callback_query_handler(func=lambda call: call.data == 'add_funds')
def add_funds(call):
    markup = types.InlineKeyboardMarkup()
    uzcard_btn = types.InlineKeyboardButton("Uzcard", callback_data='requisite_uzcard')
    humo_btn = types.InlineKeyboardButton("Humo", callback_data='requisite_humo')
    markup.add(uzcard_btn, humo_btn)

    bot.send_message(call.message.chat.id, "Выберите реквизит для пополнения:", reply_markup=markup)


@bot.callback_query_handler(func=lambda call: call.data in ['requisite_uzcard', 'requisite_humo'])
def handle_requisite_selection(call):
    user_id = call.from_user.id
    requisite = "Uzcard" if call.data == 'requisite_uzcard' else "Humo"
    user_states[user_id] = {'requisite': requisite}

    requisite_message = (f"Вы выбрали реквизит {requisite}:\n"
                         f"```\n8600 1234 5678 9000\n```" if requisite == "Uzcard" else
                         f"Вы выбрали реквизит {requisite}:\n```\n9860 1234 5678 9000\n```")

    # Удаляем предыдущее сообщение перед отправкой нового
    bot.delete_message(call.message.chat.id, call.message.message_id)

    bot.send_message(call.message.chat.id, requisite_message, parse_mode='MarkdownV2')
    bot.send_message(call.message.chat.id, "Введите сумму пополнения:")


@bot.message_handler(func=lambda message: message.text.isdigit() and int(message.text) > 0)
def handle_top_up_amount(message):
    user_id = message.from_user.id
    amount = float(message.text)

    if user_id in user_states and 'requisite' in user_states[user_id]:
        requisite = user_states[user_id]['requisite']
    else:
        bot.send_message(message.chat.id, "❌ Пожалуйста, сначала выберите реквизит.")
        return

    bot.send_message(message.chat.id,
                     f"Вы ввели сумму: {amount} 💵. Пожалуйста, отправьте скриншот подтверждения оплаты.")

    user_states[user_id]['amount'] = amount
    bot.register_next_step_handler(message, handle_screenshot)


def handle_screenshot(message):
    user_id = message.from_user.id

    if message.content_type == 'photo':
        amount = user_states[user_id]['amount']
        requisite = user_states[user_id]['requisite']

        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        admin_message = (f"📩 Новый платеж:\n"
                         f"Сумма: {amount} 💵\n"
                         f"Реквизит: {requisite}\n"
                         f"Пользователь: {message.from_user.first_name} (ID: {user_id})\n"
                         f"Время: {timestamp}")

        markup = types.InlineKeyboardMarkup()
        top_up_button = types.InlineKeyboardButton(
            f"💵 Пополнить счет на {amount} 💵",
            callback_data=f'top_up_{user_id}_{amount}'
        )
        fake_check_button = types.InlineKeyboardButton(
            "❌ Чек фейковый",
            callback_data=f'fake_check_{user_id}'
        )
        markup.add(top_up_button, fake_check_button)

        bot.send_photo(ADMIN_ID, message.photo[-1].file_id, caption=admin_message, reply_markup=markup)
        bot.send_message(user_id, "✅ Спасибо! Ваш платеж отправлен на проверку.")
    else:
        bot.send_message(message.chat.id, "❌ Пожалуйста, отправьте изображение (скриншот подтверждения платежа).")
        bot.register_next_step_handler(message, handle_screenshot)


@bot.callback_query_handler(func=lambda call: call.data.startswith('fake_check_'))
def handle_fake_check(call):
    try:
        user_id_str = call.data.split('_')[-1]
        user_id = int(user_id_str)

        bot.send_message(user_id, "❌ Уведомление: Отправленный вами чек оказался фейковым.")
        bot.send_message(call.message.chat.id, f"✅ Чек пользователя {user_id} отмечен как фейковый.")
    except ValueError:
        bot.send_message(call.message.chat.id, "❌ Неверный формат данных.")
    except Exception as e:
        bot.send_message(ADMIN_ID, "Ошибка при обработке данных: " + str(e))
        print(f"Ошибка: {e}")


@bot.callback_query_handler(func=lambda call: call.data == 'recent_purchases')
def recent_purchases(call):
    user_id = call.from_user.id
    purchases = get_recent_purchases(user_id)

    if purchases:
        purchases_message = "🛍️ Ваши недавние покупки:\n" + "\n".join(purchases)
    else:
        purchases_message = "❌ У вас нет недавних покупок."

    markup = types.InlineKeyboardMarkup()
    back_btn = types.InlineKeyboardButton("🔙 Назад", callback_data='back_to_user_cabinet')
    markup.add(back_btn)

    bot.send_message(call.message.chat.id, purchases_message, reply_markup=markup)


@bot.callback_query_handler(func=lambda call: call.data == 'back_to_user_cabinet')
def back_to_user_cabinet(call):
    # Удаляем предыдущее сообщение перед отправкой нового
    bot.delete_message(call.message.chat.id, call.message.message_id)
    show_user_cabinet(call.message)


@bot.callback_query_handler(func=lambda call: call.data == 'back_to_main_menu')
def back_to_main_menu(call):
    # Удаляем предыдущее сообщение перед отправкой нового
    bot.delete_message(call.message.chat.id, call.message.message_id)

    markup = types.InlineKeyboardMarkup(row_width=2)
    item1 = types.InlineKeyboardButton("Каталог Игр 🎮", callback_data='games')
    item2 = types.InlineKeyboardButton("Телеграм Премиум ⭐", callback_data='topup')
    item3 = types.InlineKeyboardButton("Поддержка 💻", callback_data='support')
    item4 = types.InlineKeyboardButton("Информация о боте ℹ️", callback_data='info')
    item5 = types.InlineKeyboardButton("Кабинет 👤", callback_data='cabinet')
    markup.add(item1, item2, item3, item4, item5)

    bot.send_message(call.message.chat.id, "Пожалуйста, выберите раздел:", reply_markup=markup)
